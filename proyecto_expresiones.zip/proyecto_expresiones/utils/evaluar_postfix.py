def evaluar_postfix(expresion):
    pila = []
    tokens = expresion.strip().split()

    for token in tokens:
        if token.isnumeric():
            pila.append(float(token))
        else:
            b = pila.pop()
            a = pila.pop()
            if token == '+':
                pila.append(a + b)
            elif token == '-':
                pila.append(a - b)
            elif token == '*':
                pila.append(a * b)
            elif token == '/':
                pila.append(a / b)
            elif token == '^':
                pila.append(a ** b)

    return pila[0]

