import re

def es_expresion_valida(expresion):
    if not re.fullmatch(r'[0-9\s+\-*/^()]+', expresion.strip()):
        return False

    pila = []
    for c in expresion:
        if c == '(':
            pila.append(c)
        elif c == ')':
            if not pila:
                return False
            pila.pop()

    if pila:
        return False

    tokens = expresion.strip().split()
    operadores = {'+', '-', '*', '/', '^'}
    ultimo = ''

    for token in tokens:
        if token in operadores and ultimo in operadores:
            return False
        ultimo = token

    return True
