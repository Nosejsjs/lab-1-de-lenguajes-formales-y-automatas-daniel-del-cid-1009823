def infix_a_postfix(expresion):
    precedencia = {'+': 1, '-': 1, '*': 2, '/': 2, '^': 3}
    salida = []
    pila = []
    tokens = expresion.strip().split()

    for token in tokens:
        if token.isnumeric():
            salida.append(token)
        elif token == '(':
            pila.append(token)
        elif token == ')':
            while pila and pila[-1] != '(':
                salida.append(pila.pop())
            if pila and pila[-1] == '(':
                pila.pop()
        else:
            while (pila and pila[-1] != '(' and
                   precedencia.get(token, 0) <= precedencia.get(pila[-1], 0)):
                salida.append(pila.pop())
            pila.append(token)

    while pila:
        salida.append(pila.pop())

    return ' '.join(salida)

