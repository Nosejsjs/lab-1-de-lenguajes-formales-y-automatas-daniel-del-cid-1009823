from utils.validador import es_expresion_valida
from utils.infix_postfix import infix_a_postfix
from utils.evaluar_postfix import evaluar_postfix

def main():
    with open('expresiones.txt', 'r') as archivo:
        lineas = archivo.readlines()

    for i, linea in enumerate(lineas):
        expresion = linea.strip()
        if not expresion:
            print(f"Línea {i+1}: vacía, descartada.")
            continue

        if not es_expresion_valida(expresion):
            print(f"Línea {i+1}: '{expresion}' no es válida.")
            continue

        try:
            postfix = infix_a_postfix(expresion)
            resultado = evaluar_postfix(postfix)
            print(f"\nExpresión infix: {expresion}")
            print(f"Postfix: {postfix}")
            print(f"Resultado: {resultado}")
        except Exception as e:
            print(f"Error en línea {i+1}: {e}")

if __name__ == "__main__":
    main()
