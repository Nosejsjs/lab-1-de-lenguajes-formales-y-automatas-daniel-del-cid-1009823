lo hice individual y pues solo tiene que poner: 

python main.py
en una nueva terminal.

use ia para corregir un error porque trataba de ejecutar el programa pero me daba un error, entonces le pregunte esto: este error sigue apareciendo cuando uso py main.py en la terminal: ImportError: cannot import name 'es_expresion_valida' from 'utils.validador' (C:\Users\Daniel\Downloads\Hoja de trabajo 1 lenguajes formales y automatas\utils\validador.py)

trato de darme otra solucion pero me dio como resultado esto:
PS C:\Users\Daniel\Downloads\Hoja de trabajo 1 lenguajes formales y automatas> python
Python 3.13.5 (tags/v3.13.5:6cb20a2, Jun 11 2025, 16:15:46) [MSC v.1943 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license" for more information.
>>> from utils import validador
... validador.es_expresion_valida("3 + 4")
... 
Traceback (most recent call last):
  File "<python-input-0>", line 2, in <module>
    validador.es_expresion_valida("3 + 4")
    ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
AttributeError: module 'utils.validador' has no attribute 'es_expresion_valida'
>>> 

eso fue lo que me lanzó al poner pyton en la terminal y luego from utils import validador
validador.es_expresion_valida("3 + 4")

resulta que no funciono, me dio esto y le pregunte esto:

No me devolvio true. me devolvio esto:

PS C:\Users\Daniel\Downloads\Hoja de trabajo 1 lenguajes formales y automatas> python
Python 3.13.5 (tags/v3.13.5:6cb20a2, Jun 11 2025, 16:15:46) [MSC v.1943 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license" for more information.
>>> from utils import validador_funciones
... validador_funciones.es_expresion_valida("3 + 4")
... 
Traceback (most recent call last):
  File "<python-input-0>", line 2, in <module>
    validador_funciones.es_expresion_valida("3 + 4")
    ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
AttributeError: module 'utils.validador_funciones' has no attribute 'es_expresion_valida'
>>> 


luego al ejecturar pyhton main.py me dio esto:
PS C:\Users\Daniel\Downloads\Hoja de trabajo 1 lenguajes formales y automatas> python main.py
Traceback (most recent call last):
  File "C:\Users\Daniel\Downloads\Hoja de trabajo 1 lenguajes formales y automatas\main.py", line 1, in <module>
    from utils.validador import es_expresion_valida
ModuleNotFoundError: No module named 'utils.validador'
PS C:\Users\Daniel\Downloads\Hoja de trabajo 1 lenguajes formales y automatas> 


luego de probar de todo, lo que me recomendó fue solo hacer una carpeta desde 0 pero poniendo mi codigo y todos los archivos como estaban solo que en una nueva carpeta y funcionó, perdi mucho tiempo tratando de arreglar el error, al parecer la carpeta estaba corrupta o algo, por eso entrego este lab algo tarde pero para hacerlo solo espero me tenga piedad unu.